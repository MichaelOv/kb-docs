[{include file="pages/frameloader.tpl"}]

<div class="gradient content-header">
	<img src="../images/icons/silk/world.png" class="vam mr5" /><span class="bold text-shadow headline vam">portal.i-doit.com</span>
</div>
<iframe src="http://portal.i-doit.com" style="border:0" id="_iframe" height="100%" width="100%" />