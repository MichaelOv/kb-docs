<?php
/**
 * Classmap generated on 2023-02-07
 */

return [
    'isys_update' => 'updates/classes/isys_update.class.php',
    'isys_update_config' => 'updates/classes/isys_update_config.class.php',
    'isys_update_files' => 'updates/classes/isys_update_files.class.php',
    'isys_update_log' => 'updates/classes/isys_update_log.class.php',
    'isys_update_migration' => 'updates/classes/isys_update_migration.class.php',
    'isys_update_modules' => 'updates/classes/isys_update_modules.class.php',
    'isys_update_property_migration' => 'updates/classes/isys_update_property_migration.class.php',
    'isys_update_xml' => 'updates/classes/isys_update_xml.class.php',
];
