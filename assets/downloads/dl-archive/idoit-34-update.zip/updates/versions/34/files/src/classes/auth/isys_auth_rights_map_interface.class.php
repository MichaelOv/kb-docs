<?php

interface isys_auth_rights_map_interface
{
    public function getRightsMap(): array;
}
