<?php

namespace idoit\Module\Forms\Model\Processors\Interfaces;

interface PreMergeModifierInterface
{
    /**
     * @param array $data
     * @param int $objectId
     *
     * @return array
     */
    public function preMergeModify(array $data, int $objectId): array;
}
