<link rel="stylesheet" type="text/css" href="[{$formsDocumentRoot}]src/classes/modules/forms/react/dist/styles.css">
<style type='text/css'>
  .idoit-forms-banner {
    box-sizing: border-box;
    box-shadow: 0 16px 24px rgb(0 0 0 / 16%), 0 16px 32px rgb(0 0 0 / 16%), 0 0 24px rgb(0 0 0 / 8%);
    margin: 40px;
    max-width: min-content;
    border-radius: 4px;
    overflow: hidden;
    font-size: 13px;
    line-height: 1.2307692308;
    white-space: nowrap;
    font-family: 'Inter';
  }

  .idoit-forms-banner--header {
    background-color: #e3000f;
    color: #fff;
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    width: 100%;
    height: 52px;
    font-weight: 600;
    padding: 4px 16px;
  }

  .idoit-forms-banner--header svg {
    margin-right: 12px;
    width: 20px;
    height: 20px;
    fill: white;
  }
</style>

<div class="idoit-forms-banner">
  <div class="idoit-forms-banner--header">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z"></path>
    </svg>

    <div>[{$errorMessage}]</div>
  </div>
</div>
