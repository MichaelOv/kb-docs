[{$searchResultList}]
