<head>
	[{if $title}]
		<title>i-doit - [{$title}]</title>
	[{else}]
		<title>i-doit - [{isys type="breadcrumb_navi" name="breadcrumb" p_plain=true p_append=" > "}]</title>
	[{/if}]

	<meta name="author" content="synetics gmbh" />
	<meta name="description" content="i-doit" />
	<meta name="keywords" content="i-doit, CMDB, ITSM, ITIL, NMS, Netzwerk, Dokumentation, Documentation" />
	<meta http-equiv="content-type" content="text/html; charset=[{$html_encoding|default:"utf-8"}];" />
	<meta name="robots" content="noindex" />

	<!-- This meta tag will force the internet explorer to disable the "compability" mode -->
	<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->

	<link rel="icon" type="image/png" href="images/favicon.png">
	<!--[if IE]><link rel="shortcut icon" href="images/favicon.ico" /><![endif]-->

	<link rel="stylesheet" type="text/css" media="print" href="[{$dir_theme}]css/print.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="?load=css&theme=[{$theme|default:"default"}]&token=[{isys_tenantsettings::get('system.last-change',time())}]" />
	<link rel="stylesheet" type="text/css" media="screen" href="?load=mod-css&theme=[{$theme|default:"default"}]&token=[{isys_tenantsettings::get('system.last-change',time())}]" />

	<script type="text/javascript">
        var C__CMDB__GET__OBJECT      = "[{$object}]",
            C__CMDB__GET__TREEMODE    = "[{$treemode}]",
            C__CMDB__GET__VIEWMODE    = "[{$viewmode}]",
            C__CMDB__GET__OBJECTTYPE  = "[{$objtype}]",
            C__CMDB__GET__OBJECTGROUP = "[{$objgroup}]",
            C__GET__NAVMODE           = "[{$smarty.const.C__GET__NAVMODE}]",
            C__NAVMODE__JS_ACTION     = "[{$smarty.const.C__NAVMODE__JS_ACTION}]";

		[{$errorTrackerCode}]
	</script>

	<script type="text/javascript" src="[{$dir_tools}]js/prototype/prototype.js"></script>
	<script type="text/javascript" src="[{$dir_tools}]js/scriptaculous/src/scriptaculous.js?load=effects,dragdrop,controls"></script>
	<script type="text/javascript" src="[{$dir_tools}]js/taborder/taborder.js"></script>
	<script type="text/javascript" src="[{$dir_tools}]js/ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="[{$dir_tools}]js/bluff/js-class.js" defer></script>
	<script type="text/javascript" src="[{$dir_tools}]js/bluff/bluff-min.js" defer></script>

	<script type="text/javascript" src="[{$dir_tools}]js/scripts.js?token=[{isys_tenantsettings::get('system.last-change','1337')}]"></script>
	<script type="text/javascript" src="[{$dir_tools}]js/prototip/prototip.js"></script>

	<!--suppress JSFileReferences -->
	<script type="text/javascript">
        /* <![CDATA[ */
        globalize(C__CMDB__GET__TREEMODE, '[{$smarty.get.$treemode|escape}]');
        globalize(C__CMDB__GET__OBJECT, '[{$smarty.get.$object|escape}]');
        globalize(C__CMDB__GET__OBJECTTYPE, '[{$smarty.get.$objtype|escape}]');

		[{include file="lang.js"}]

        Event.observe(window, 'load', function () {
            onload_process();
        });

        idoit.Require.config({
            paths: {
                d3v3:                    "[{$dir_tools}]js/d3/d3-v3.5.5-min.js",
                d3v3cola:                "[{$dir_tools}]js/d3/cola-v3.1.0-min.js",
                d3:                      "[{$dir_tools}]js/d3/d3-v4.11.0-min.js",
                d3cola:                  "[{$dir_tools}]js/d3/cola-v3.3.6-min.js",
                d3VisConnection:         "[{$dir_tools}]js/d3/visualization/connections.js",
                d3ChartPie:              "[{$dir_tools}]js/d3/charts/pie.js",
                d3ChartBar:              "[{$dir_tools}]js/d3/charts/bar.js",
                d3ChartStacked:          "[{$dir_tools}]js/d3/charts/stacked.js",
                introjs:                 "[{$dir_tools}]js/introjs/introjs.min.js",
                jit:                     "[{$dir_tools}]js/jit/jit.js",
                bluff:                   "[{$dir_tools}]js/bluff/bluff-min.js",
                jsclass:                 "[{$dir_tools}]js/bluff/js-class.js",
                qcw:                     "[{$dir_tools}]js/qcw/quick_configuration_wizard.js",
                taborder:                "[{$dir_tools}]js/taborder/taborder.js",
                ckeditor:                "[{$dir_tools}]js/ckeditor/ckeditor.js",
                authConfiguration:       "[{$dir_tools}]js/auth/configuration.js",
                simpleAuthConfiguration: "[{$dir_tools}]js/auth/simple_configuration.js",
                fileUploader:            "[{$dir_tools}]js/ajax_upload/fileuploader.js",
            }
        });
        /* ]]> */
	</script>

	[{foreach from=$jsFiles item="jsFile"}]
		<script type="text/javascript" src="[{$jsFile}]"></script>
	[{/foreach}]
</head>

<body id="body">