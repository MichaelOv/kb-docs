[{if isset($g_list)}]
	[{$g_list}]
[{else}]
	<input type="hidden" name="list_objtype_id" value="[{$list_obj_type_id}]">

	<div class="p5">
		<table class="contentTable">
			<tr>
				<td class="key">[{isys type="f_label" name="sorting_direction" ident="LC__REPORT__INFO__SORTING"}]</td>
				<td class="value">[{isys type="f_dialog" name="sorting_direction" p_bDbFieldNN='1' p_arData=$sorting_data p_strSelectedID=$defined_sorting p_bEditMode=1 p_strClass="input-mini" disableInputGroup=true}]</td>
			</tr>
			<tr>
				<td class="key">[{isys type="f_label" name="grouping_type" ident="LC__MODULE__CMDB__GROUPING_TYPE"}]</td>
				<td class="value">[{isys type="f_dialog" name="grouping_type" p_bDbFieldNN='1' p_arData=$groupingData p_strSelectedID=$groupingSelection p_bEditMode=1 p_strClass="input-small" disableInputGroup=true}]</td>
			</tr>
			<tr>
				<td class="key vat">[{isys type="f_label" name="default_filter_field" ident="LC__MODULE__CMDB__DEFAULT_FILTER"}]</td>
				<td class="value">
					[{isys type="f_dialog" name="default_filter_field" p_arData=$defaultFilterFields p_strSelectedID=$defaultFilterField p_bEditMode=1 p_strClass="input-mini" p_bDbFieldNN=true}]
					[{isys type="f_text" name="default_filter_value" p_strValue=$defaultFilterValue p_bEditMode=1 p_strClass="input-mini"}]
					<br class="cb" />
					<p class="m5 ml20 p5 box-blue"><img src="[{$dir_images}]icons/silk/information.png" class="vam mr5" /><span class="vam">[{isys type="lang" ident="LC__MODULE__CMDB__DEFAULT_FILTER_DESCRIPTION"}]</span></p>
				</td>
			</tr>
			<tr>
				<td class="key"></td>
				<td class="value pl20">[{isys type="checkbox" p_bInfoIconSpacer=0 name="default_filter_wildcard" p_bEditMode=1 p_bChecked=$default_filter_wildcard p_strTitle="LC__MODULE__CMDB__DEFAULT_FILTER_WILDCARD"}]</td>
			</tr>
			<tr>
				<td class="key"></td>
				<td class="value pl20">[{isys type="checkbox" p_bInfoIconSpacer=0 name="row_clickable" p_bEditMode=1 p_bChecked=$row_clickable p_strTitle="LC__MODULE__CMDB__ROW_CLICK_FEATURE"}]</td>
			</tr>
		</table>
		<table class="contentTable">
			<tr>
				<td class="key">[{isys type="f_label" name="advanced_option_memory_unit" ident="LC__MODULE__CMDB__ADVANCED_OPTION__MEMORY_UNIT"}]</td>
				<td class="value">[{isys type="f_dialog" p_bSort=false name="advanced_option_memory_unit" p_bDbFieldNN='1' p_arData=$memory_unit_data p_strSelectedID=$defined_memory_unit p_bEditMode=1 p_strClass="input-mini" disableInputGroup=true}]</td>
			</tr>
		</table>
	</div>

	[{isys
		type="f_property_selector"
		obj_type_id=$list_obj_type_id
		p_bInfoIconSpacer=0
		name="list"
		p_strStyle="margin-left:5px;"
		custom_fields=true
		grouping=false
		sortable=true
		preselection=$selected_properties
		dynamic_properties=true
		provide=$provides
		allow_sorting=true
		default_sorting=$default_sorting
		check_sorting=true
		p_consider_rights=true
		max_items=isys_tenantsettings::get('cmdb.limits.object-table-columns', 10)
		callback_add="window.updateDefaultFilterAttributes"
		callback_remove="window.updateDefaultFilterAttributes"}]

	<p class="m5">
		<a href="?[{$smarty.const.C__CMDB__GET__VIEWMODE}]=[{$smarty.const.C__CMDB__VIEW__LIST_OBJECT}]&&objTypeID=[{$smarty.get.objTypeID|escape}]" class="btn">
			<img src="[{$dir_images}]icons/silk/table.png" class="vam" /> [{isys type="lang" ident="LC__MODULE__CMDB__LIST__JUMP_TO_LIST"}]
		</a>
		<button type="button" id="resetter" class="btn redbg">
			<img src="[{$img_dir}]icons/silk/cross.png" class="vam" /> [{isys type="lang" ident="LC__MODULE__CMDB__RESTORE_DEFAULT_LIST_CONFIG"}]
		</button>
	</p>

	[{if $has_right_to_overwrite || $has_right_to_define_standard}]
	<hr class="mt10 mb10" />

	<table class="two-col" style="width:100%;">
		<tr>
			[{if $has_right_to_overwrite}]
			<td class="p5 vat">
				<h3 class="p5 gradient border">[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER"}]</h3>
				<p class="mt5 mb5">[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER_DESCRIPTION"}]</p>

				[{isys
					type="f_popup"
					p_strPopupType="browser_object_ng"
					name="C__CMDB__PERSON__SELECTION"
					catFilter="C__CATS__PERSON;C__CATS__PERSON_LOGIN"
					multiselection=true
					p_bInfoIconSpacer=0
					p_strClass="input-small"
					inputGroupMarginClass=""}]

				<button type="button" id="C__CMDB__BUTTON_SET_FOR_USER" class="ml20 btn">
					<img src="[{$dir_images}]icons/silk/table_add.png" class="mr5" /><span>[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER_BUTTON"}]</span>
				</button>
			</td>
			[{/if}]

			[{if $has_right_to_define_standard}]
			<td class="p5 vat">
				<h3 class="p5 gradient border">[{isys type="lang" ident="LC__MODULE__CMDB__SET_AS_DEFAULT"}]</h3>
				<p class="mt5 mb5">[{isys type="lang" ident="LC__MODULE__CMDB__SET_AS_DEFAULT_DESCRIPTION"}]</p>
				<button type="button" id="C__CMDB__BUTTON_SET_AS_DEFAULT" class="btn"><img src="[{$dir_images}]icons/silk/accept.png" class="mr5" /><span>[{isys type="lang" ident="LC__MODULE__CMDB__SET_AS_DEFAULT_BUTTON"}]</span></button>
			</td>
			[{/if}]
		</tr>
	</table>
	[{/if}]

	<script type="text/javascript">
	(function () {
		'use strict';

		var $button_set_for_user = $('C__CMDB__BUTTON_SET_FOR_USER'),
			$button_set_as_default = $('C__CMDB__BUTTON_SET_AS_DEFAULT'),
			$personObjectSelection = $('C__CMDB__PERSON__SELECTION__HIDDEN'),
			$selectDefaultFilter = $('default_filter_field'),
			constantToDaoMatcher = {};

		$('resetter').on('click', function () {
			if (confirm('[{isys type="lang" p_bHtmlEncode=0 ident="LC__MODULE__CMDB__RESTORE_DEFAULT_LIST_CONFIG_CONFIRM"}]'))
			{
				$('sort').setValue('default_values');
				$('isys_form').submit();
			}
		});

		if ($button_set_for_user && $personObjectSelection) {
			$button_set_for_user.on('click', function () {
				var default_sorting = $('list_selection_field').down('input:checked');

				if ($personObjectSelection.getValue().blank()) {
					idoit.Notify.info('[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER_NOTICE"}]', {life:10});
					return;
				}

				if (confirm('[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER_CONFIRM" p_bHtmlEncode=false}]')) {
					$button_set_for_user.disable()
						.down('img').writeAttribute('src', window.dir_images + 'ajax-loading.gif')
						.next('span').update('[{isys type="lang" ident="LC__UNIVERSAL__LOADING"}]');

					new Ajax.Request('[{$ajax_url}]', {
						parameters: {
							'[{$smarty.const.C__GET__NAVMODE}]': '[{$smarty.const.C__NAVMODE__SAVE}]',
							list__HIDDEN: $F('list__HIDDEN'),
							list__HIDDEN_IDS: $F('list__HIDDEN_IDS'),
							row_clickable: $('row_clickable').checked ? 'on' : '',
							default_sorting: (default_sorting ? default_sorting.getValue() : null),
							sorting_direction: $F('sorting_direction'),
							for_users: '1',
							users: $personObjectSelection.getValue(),
							object_type: '[{$objecttype.isys_obj_type__const}]',
							default_filter_wildcard: $('default_filter_wildcard').checked ? 'on' : ''
						},
						onComplete: function (xhr) {
							// Nothing to do here. Notify popups will be triggered by PHP.
							$button_set_for_user.enable()
								.down('img').writeAttribute('src', window.dir_images + 'icons/silk/table_add.png')
								.next('span').update('[{isys type="lang" ident="LC__MODULE__CMDB__SET_FOR_USER_BUTTON"}]');
						}
					})
				}
			});
		}

		if ($button_set_as_default) {
			$button_set_as_default.on('click', function () {
				if (confirm('[{isys type="lang" ident="LC__MODULE__CMDB__SET_AS_DEFAULT_CONFIRM" p_bHtmlEncode=false}]')) {
					$button_set_as_default.disable()
						.down('img').writeAttribute('src', window.dir_images + 'ajax-loading.gif')
						.next('span').update('[{isys type="lang" ident="LC__UNIVERSAL__LOADING"}]');

					new Ajax.Request('[{$ajax_url}]', {
						parameters: {
							'[{$smarty.const.C__GET__NAVMODE}]': '[{$smarty.const.C__NAVMODE__SAVE}]',
							list__HIDDEN: $F('list__HIDDEN'),
							list__HIDDEN_IDS: $F('list__HIDDEN_IDS'),
							as_default: '1',
							object_type: '[{$objecttype.isys_obj_type__const}]',
							row_clickable: $('row_clickable').checked ? 'on' : '',
							default_filter_wildcard: $('default_filter_wildcard').checked ? 'on' : ''
						},
						onComplete: function (xhr) {
							// Nothing to do here. Notify popups will be triggered by PHP.
							$button_set_as_default.enable()
								.down('img').writeAttribute('src', window.dir_images + 'icons/silk/accept.png')
								.next('span').update('[{isys type="lang" ident="LC__MODULE__CMDB__SET_AS_DEFAULT_BUTTON"}]');
						}
					});
				}
			});
		}

        window.updateDefaultFilterAttributes = function () {
            var $selectedProperties = $('list_selection_field').select('.property'),
                label,
                attributeLabel,
                categoryLabel,
                categoryConst,
                propertyKey,
                defaultFilterList   = [],
                constantsToLoad     = [],
                i;

            $selectDefaultFilter.store('previousValue', $selectDefaultFilter.getValue()).disable();

            for (i in $selectedProperties) {
                if (!$selectedProperties.hasOwnProperty(i)) {
                    continue;
                }

                propertyKey = $selectedProperties[i].readAttribute('data-propkey');
                categoryConst = $selectedProperties[i].readAttribute('data-catconst');

                // @see ID-4707 This needs to be fixed in the future
                if (propertyKey === 'cmdb_status' && categoryConst === 'C__CATG__GLOBAL') {
                    continue;
                }

                label = $selectedProperties[i].down('span').innerText;
                categoryLabel = '';

                try {
                    label = label.match(/(.*)\((.*?)\)$/);
                    categoryLabel = label[2] + ' > ';
                    attributeLabel = label[1]
                } catch (e) {
                    attributeLabel = $selectedProperties[i].down('span').innerText;
                }

                if (!constantToDaoMatcher.hasOwnProperty(categoryConst)) {
                    constantsToLoad.push(categoryConst);
                }

                defaultFilterList.push({
                    categoryConst: categoryConst,
                    label:         categoryLabel + attributeLabel,
                    propertyKey:   propertyKey,
                    daoClass:      constantToDaoMatcher[categoryConst] || null,
                    value:         null
                });
            }

            if (defaultFilterList.length) {
                window.processDefaultFilterValues(defaultFilterList, constantsToLoad);
            }
        };

        window.processDefaultFilterValues = function (defaultFilterList, constantsToLoad) {
            var i;

            if (constantsToLoad.length) {
                new Ajax.Request('?call=get_category_data&ajax=1&func=get_dao_classes_by_constants', {
                    parameters: {
                        constants: constantsToLoad.join()
                    },
                    onComplete: function (xhr) {
                        var json = xhr.responseJSON;

                        if (json.success) {
                            for (i in defaultFilterList) {
                                if (!defaultFilterList.hasOwnProperty(i) || !json.data.hasOwnProperty(defaultFilterList[i].categoryConst)) {
                                    continue;
                                }

                                // Fill up the matcher.
                                constantToDaoMatcher[defaultFilterList[i].categoryConst] = json.data[defaultFilterList[i].categoryConst];

                                defaultFilterList[i].daoClass = json.data[defaultFilterList[i].categoryConst];
                                defaultFilterList[i].value = defaultFilterList[i].daoClass + '__' + defaultFilterList[i].propertyKey;
                            }

                            window.renderDefaultFilterSelect(defaultFilterList);
                        } else {
                            idoit.Notify.error(json.message, {sticky: true});
                        }
                    }
                });
            } else {
                window.renderDefaultFilterSelect(defaultFilterList);
            }
        };

        window.renderDefaultFilterSelect = function (defaultFilterList) {
            var i;

            $selectDefaultFilter.update();
            $selectDefaultFilter.enable();

            defaultFilterList.sort(function (a, b) {
                return a.label.localeCompare(b.label);
            });

            for (i in defaultFilterList) {
                if (!defaultFilterList.hasOwnProperty(i)) {
                    continue;
                }

                if (defaultFilterList[i].daoClass === 'isys_cmdb_dao_category_g_custom_fields') {
                    continue;
                }

                // isys_cmdb_dao_category_g_global__title
                $selectDefaultFilter.insert(new Element('option', {value: defaultFilterList[i].value}).update(defaultFilterList[i].label))
            }

            $selectDefaultFilter.setValue($selectDefaultFilter.retrieve('previousValue'));
        };
	})();
	</script>
[{/if}]