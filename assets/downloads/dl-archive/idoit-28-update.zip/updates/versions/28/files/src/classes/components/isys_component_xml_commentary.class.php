<?php

/**
 * @package     i-doit
 * @subpackage  Components_XML
 * @copyright   synetics GmbH
 * @license     http://www.i-doit.com/license
 */
class isys_component_xml_commentary extends isys_component_xml_object
{
    /**
     * @var  string
     */
    private $strCommentary = null;

    /**
     * Output commentary.
     *
     * @return  string
     */
    public function get_object()
    {
        return "<!--" . $this->strCommentary . "-->";
    }

    /**
     * Constructor.
     *
     * @param  string $p_strCommentary
     */
    public function __construct($p_strCommentary)
    {
        $this->strCommentary = $p_strCommentary;
    }
}
