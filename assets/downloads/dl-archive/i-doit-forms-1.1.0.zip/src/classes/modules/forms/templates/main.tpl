[{isys type="f_react_bridge" component=$reactComponent params=$reactParams}]

<link rel="stylesheet" type="text/css" href="[{$formsDocumentRoot}]src/classes/modules/forms/react/dist/styles.css">
<script type="text/javascript">
    // Mark the "extras" menu.
    $('mainMenu').select('li').each(function($el) {
        if ($el.hasClassName('extras')) {
            $el.addClassName('active');
        } else {
            $el.removeClassName('active');
        }
    });

    new dragBar({
        dragContainer:  'draggableBar',
        leftContainer:  'menuTreeOn',
        rightContainer: 'contentArea',
        moveInfoBox:    true,
        defaultWidth:   0
    }).deactivateBar();

    $('isys_form').on('submit', (ev) => {
      ev.preventDefault();
    });

    try {
      window.currentUser = JSON.parse('[{$currentUser|json_encode|escape:"javascript"}]');
    } catch {
      window.currentUser = {name: 'anonymous', id: '0'};
    }
</script>
